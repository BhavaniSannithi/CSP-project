import { Component } from '@angular/core';


@Component({
  selector: 'app-backgroundslider',
  templateUrl: './backgroundslider.component.html',
  styleUrls: ['./backgroundslider.component.css']
})
export class BackgroundsliderComponent {
  

}
