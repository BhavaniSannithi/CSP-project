import { Component } from '@angular/core';

@Component({
  selector: 'app-sa',
  templateUrl: './sa.component.html',
  styleUrls: ['./sa.component.css']
})
export class SaComponent {

}
